#include "points.h"
#ifndef GLOBAL_H
#define GLOBAL_H

extern double BOUNDmaxx;
extern double BOUNDminx;
extern double BOUNDmaxy;
extern double BOUNDminy;
extern Point sweeper;

#endif // GLOBAL_H